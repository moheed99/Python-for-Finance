
def calculate_net_income(revenue, expenses):
    try:
        revenue = float(revenue)
        expenses = float(expenses)
        if revenue < 0 or expenses < 0:
            return "Error: Revenue and expenses cannot be negative."
        net_income = revenue - expenses
        if revenue > 5000:
            tax = 0.10 * net_income
            net_income -= tax
        return net_income
    except ValueError:
        return "Error: Invalid input. Please enter numeric values for revenue and expenses."