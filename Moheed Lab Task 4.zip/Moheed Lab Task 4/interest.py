def simple_interest(principal, rate, time):
    try:
        principal = float(principal)
        rate = float(rate)
        time = float(time)
        if principal < 0 or rate < 0 or time < 0:
            return "Error: Please enter positive values."
        interest = (principal * rate * time) / 100
        return interest
    except ValueError:
        return "Error: Please enter numbers for principal, rate, and time."

def compound_interest(principal, rate, time, n):
    try:
        principal = float(principal)
        rate = float(rate)
        time = float(time)
        n = float(n)
        if principal < 0 or rate < 0 or time < 0 or n < 0:
            return "Error: Please enter positive values."
        amount = principal * (1 + (rate / 100) / n) ** (n * time)
        interest = amount - principal
        return interest
    except ValueError:
        return "Error: Please enter numbers for principal, rate, time, and n."


